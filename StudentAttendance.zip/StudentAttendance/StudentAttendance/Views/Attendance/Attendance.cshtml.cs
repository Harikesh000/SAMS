using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace StudentAttendance.Views.Attendance
{
    public class AttendanceModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

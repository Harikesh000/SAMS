﻿using Microsoft.AspNetCore.Mvc;
using StudentAttendance.Data;

namespace StudentAttendance.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            // If already logged in, go straight to Dashboard
            if (HttpContext.Session.GetInt32("fid") != null)
                return RedirectToAction("Dashboard", "Home");

            return View();
        }

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            // Find user by email/password
            var user = _context.Faculty.FirstOrDefault(u => u.Email == email && u.Password == password);

            if (user != null)
            {
                
                HttpContext.Session.SetInt32("fid", user.Id);
                HttpContext.Session.SetString("FacultyEmail", user.Email);
                HttpContext.Session.SetString("FacultyName", user.Name ?? "Unknown");
                HttpContext.Session.SetString("FacultyDept", user.DepartmentId ?? "Unknown");

                
                var currentSem = _context.CurrentSem.FirstOrDefault();
                if (currentSem != null)
                {
                   
                    HttpContext.Session.SetString("csem", currentSem.IsOdd);
                }

                
                return RedirectToAction("Dashboard", "Home");
            }

           
            ViewBag.Error = "Invalid email or password";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}

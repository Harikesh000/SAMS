using Microsoft.AspNetCore.Mvc;
using StudentAttendance.Data;
using StudentAttendance.Models;

namespace StudentAttendance.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;
        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }
        private string GetShortForm(string subjectName)
        {
            var words = subjectName.Split(' ');
            var ignore = new HashSet<string> { "and", "of", "the", "in", "on", "for", "with" };
            return string.Concat(words.Where(w => !ignore.Contains(w.ToLower()))
                                      .Select(w => w[0].ToString().ToUpper()));
        }
        public IActionResult Dashboard()
        {
            // Check if user is logged in
            var userEmail = HttpContext.Session.GetString("FacultyEmail");
            if (string.IsNullOrEmpty(userEmail))
                return RedirectToAction("Login", "Account");

            // Pass user name to View
            ViewBag.FacultyName = HttpContext.Session.GetString("FacultyName");
            var uid = HttpContext.Session.GetInt32("fid");
            if (uid == null)
                return RedirectToAction("Login", "Account"); // Redirect if not logged in

            string facultyDeptRaw = HttpContext.Session.GetString("FacultyDept"); // "1,2"
            List<int> deptIds = facultyDeptRaw.Split(',')
                .Select(id => int.Parse(id.Trim()))
                .ToList();

            var departments = _context.Department
                .Where(d => deptIds.Contains(d.Id))
                .ToList();

            var subjectsByDept = new Dictionary<int, List<(string shortName, string fullName, int subjectId,int sem,int totalLectures)>>();

            foreach (int deptId in deptIds)
            {
                var subjects = _context.Subjects
                    .Where(s => s.DepartmentId == deptId &&
                                s.FacultyId == uid)
                    .ToList();

                var subjectCards = subjects.Select(s =>
                {
                    string shortName = GetShortForm(s.SubjectName);
                    int totalLectures = _context.LecturesTaken
                        .Where(l => l.SubjectId == s.Id)
                        .Sum(l => l.TotalLectures);

                    return (shortName, s.SubjectName, s.Id, s.Sem,totalLectures);
                }).ToList();

                subjectsByDept[deptId] = subjectCards;
            }

            ViewBag.Departments = departments;
            ViewBag.SubjectsByDept = subjectsByDept;

            ViewBag.FacultyId = uid;
            ViewBag.UserName = HttpContext.Session.GetString("FacultyName") ?? "Unknown";
            ViewBag.CurrentSem = HttpContext.Session.GetString("csem") ?? "Unknown";

            ViewBag.FacultyDept = HttpContext.Session.GetString("FacultyDept") ?? "Unknown";
            return View();
        }

        public IActionResult Attendance()
        {
            var userEmail = HttpContext.Session.GetString("FacultyEmail");
            if (string.IsNullOrEmpty(userEmail))
                return RedirectToAction("Login", "Account");
              // Pass user name to View
            ViewBag.FacultyName = HttpContext.Session.GetString("FacultyName");
            var uid = HttpContext.Session.GetInt32("fid");
            if (uid == null)
                return RedirectToAction("Login", "Account"); // Redirect if not logged in

            ViewBag.FacultyId = uid;
            ViewBag.UserName = HttpContext.Session.GetString("FacultyName") ?? "Unknown";
            ViewBag.CurrentSem = HttpContext.Session.GetString("csem") ?? "Unknown";

            return View();
        }

    }
}

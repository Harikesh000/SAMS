﻿using Microsoft.AspNetCore.Mvc;
using StudentAttendance.Data;
using StudentAttendance.Models;


namespace StudentAttendance.Controllers
{
    public class AttendanceController: Controller
    {
        private readonly ApplicationDbContext _context;
        public AttendanceController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Mark(int subjectId)
        {

            var subject = _context.Subjects.FirstOrDefault(s => s.Id == subjectId);
            if (subject == null) return NotFound();

            Console.WriteLine($"SubjectId: {subject.Id}, DeptId: {subject.DepartmentId}, Sem: {subject.Sem}");

            var students = _context.Students
                    .Where(st => st.DepartmentId == subject.DepartmentId && st.Sem == subject.Sem)
                    .ToList();


            Console.WriteLine($"Students found: {students.Count}");
            ViewBag.Subject = subject;
            ViewBag.Students = students;

            return View("Attendance");
        }

        [HttpPost]
        public IActionResult SubmitAttendance(List<string> PresentRolls, int SubjectId, int DepartmentId, int Sem, int FacultyId)
        {
            var date = DateTime.Now.Date;
            var time = DateTime.Now.ToShortTimeString();
            var day = DateTime.Now.DayOfWeek.ToString();

            var students = _context.Students
                .Where(s => s.DepartmentId == DepartmentId && s.Sem == Sem)
                .ToList();
            if (PresentRolls != null && PresentRolls.Count > 0)
            {
                foreach (var student in students)
                {
                    var isPresent = PresentRolls.Contains(student.RollNumber);
                    var attendance = new Attendance
                    {
                        Date = date,
                        Time = time,
                        IsPresent = isPresent,
                        SubjectId = SubjectId,
                        DepartmentId = DepartmentId,
                        Day = day,
                        Sem = Sem,
                        RollNumber = student.RollNumber,
                        FacultyId = FacultyId
                    };
                    _context.Attendance.Add(attendance);
                }
                _context.SaveChanges();

                TempData["AttendanceMarked"] = "Attendance successfully submitted!";
            }

            
            return RedirectToAction("Dashboard", "Home");
        }



    }
}

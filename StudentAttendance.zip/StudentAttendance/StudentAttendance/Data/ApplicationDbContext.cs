﻿using Microsoft.EntityFrameworkCore;
using StudentAttendance.Models;

namespace StudentAttendance.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Faculty> Faculty{ get; set; }

        public DbSet<Department> Department { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<LecturesTaken> LecturesTaken { get; set; }
        public DbSet<Attendance> Attendance { get; set; }


        public DbSet<CurrentSem> CurrentSem { get; set; }
    }
}

﻿namespace StudentAttendance.Models
{
    public class Subject
    {
        public int Id { get; set; }
        public required int DepartmentId { get; set; }
        public required string SubjectName { get; set; }
        public required int Sem { get; set; }
        public required int FacultyId { get; set; }
        
    }
}

﻿namespace StudentAttendance.Models
{
    public class Attendance
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public bool IsPresent { get; set; }
        public int SubjectId { get; set; }
        public int DepartmentId { get; set; }
        public string Day { get; set; }
        public int Sem { get; set; }
        public string RollNumber { get; set; }
        public int FacultyId { get; set; }
    }
}


﻿namespace StudentAttendance.Models
{
    public class LecturesTaken
    {
        public int Id { get; set; }
        public required int TotalLectures { get; set; }
        public required int SubjectId { get; set; }
       
    }
}

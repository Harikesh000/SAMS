﻿namespace StudentAttendance.Models
{
    public class CurrentSem
    {
        public int Id { get; set; }
        public required string IsOdd { get; set; } // maps to 'isodd' column in your MySQL table
    }
}

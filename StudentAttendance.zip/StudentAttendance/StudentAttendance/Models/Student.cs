﻿namespace StudentAttendance.Models
{
    public class Student
    {
        public int Id { get; set; }
        public required string RollNumber { get; set; }
        public required int DepartmentId { get; set; }
        public required string Name { get; set; }
        public required int Sem { get; set; }
    }
}

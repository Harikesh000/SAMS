-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2025 at 11:04 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL,
  `ispresent` varchar(3) NOT NULL,
  `subjectid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  `day` varchar(15) NOT NULL,
  `sem` varchar(3) NOT NULL,
  `rollnumber` varchar(50) NOT NULL,
  `facultyid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `date`, `time`, `ispresent`, `subjectid`, `departmentid`, `day`, `sem`, `rollnumber`, `facultyid`) VALUES
(1, '2025-10-27 00:00:00', '03:02 PM', '1', 9, 1, 'Monday', '5', '202511', 1),
(2, '2025-10-27 00:00:00', '03:02 PM', '1', 9, 1, 'Monday', '5', '202512', 1),
(3, '2025-10-27 00:00:00', '03:02 PM', '1', 9, 1, 'Monday', '5', '202515', 1),
(4, '2025-10-27 00:00:00', '03:02 PM', '1', 9, 1, 'Monday', '5', '202518', 1),
(5, '2025-10-27 00:00:00', '03:06 PM', '1', 11, 1, 'Monday', '3', '202513', 1),
(6, '2025-10-27 00:00:00', '03:06 PM', '1', 11, 1, 'Monday', '3', '202516', 1),
(7, '2025-10-27 00:00:00', '03:06 PM', '1', 11, 1, 'Monday', '3', '202519', 1),
(8, '2025-10-28 00:00:00', '03:16 PM', '1', 9, 1, 'Tuesday', '5', '202511', 1),
(9, '2025-10-28 00:00:00', '03:16 PM', '1', 9, 1, 'Tuesday', '5', '202512', 1),
(10, '2025-10-28 00:00:00', '03:16 PM', '0', 9, 1, 'Tuesday', '5', '202515', 1),
(11, '2025-10-28 00:00:00', '03:16 PM', '0', 9, 1, 'Tuesday', '5', '202518', 1);

-- --------------------------------------------------------

--
-- Table structure for table `currentsem`
--

CREATE TABLE `currentsem` (
  `id` int(11) NOT NULL,
  `isodd` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `currentsem`
--

INSERT INTO `currentsem` (`id`, `isodd`) VALUES
(1, 'true');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`) VALUES
(1, 'Computer Engineering'),
(2, 'Information Technology');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `departmentid` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `departmentid`, `email`, `password`, `name`, `role`) VALUES
(1, '1,2', 'harikesh@gmail.com', '1234', 'Harikesh Yadav', 'professor'),
(2, '1', 'rishi@gmail.com', '1234', 'Rishi Yadav', 'professor');

-- --------------------------------------------------------

--
-- Table structure for table `lecturestaken`
--

CREATE TABLE `lecturestaken` (
  `id` int(11) NOT NULL,
  `totallectures` int(11) NOT NULL,
  `subjectid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `rollnumber` varchar(50) NOT NULL,
  `name` varchar(60) NOT NULL,
  `departmentid` int(11) NOT NULL,
  `sem` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `rollnumber`, `name`, `departmentid`, `sem`) VALUES
(1, '202511', 'Harikesh Yadav', 1, 5),
(2, '202521', 'Isha Patel', 2, 3),
(3, '202512', 'Rohan Mehta', 1, 5),
(4, '202522', 'Sneha Gupta', 2, 1),
(5, '202513', 'Karan Verma', 1, 3),
(6, '202523', 'Diya Nair', 2, 5),
(7, '202514', 'Manav Singh', 1, 1),
(8, '202524', 'Priya Das', 2, 3),
(9, '202515', 'Amit Joshi', 1, 5),
(10, '202525', 'Nisha Kumar', 2, 1),
(11, '202516', 'Vivek Reddy', 1, 3),
(12, '202526', 'Meera Iyer', 2, 5),
(13, '202517', 'Raj Patel', 1, 1),
(14, '202527', 'Tanya Rao', 2, 3),
(15, '202518', 'Sahil Jain', 1, 5),
(16, '202528', 'Ananya Roy', 2, 1),
(17, '202519', 'Ritika Bansal', 1, 3),
(18, '202529', 'Devansh Malhotra', 2, 5),
(19, '2025110', 'Lakshmi Pillai', 1, 1),
(20, '2025210', 'Aryan Kapoor', 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `subjectname` varchar(50) NOT NULL,
  `sem` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  `facultyid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subjectname`, `sem`, `departmentid`, `facultyid`) VALUES
(2, 'Programming Fundamentals', 1, 2, 1),
(3, 'Computer Networks', 3, 1, 2),
(4, 'Database Management System', 5, 2, 1),
(5, 'Web Technologies', 3, 1, 2),
(6, 'Data Structures', 1, 2, 2),
(7, 'Operating Systems', 5, 1, 1),
(8, 'Software Engineering', 3, 2, 2),
(9, 'Computer Architecture', 5, 1, 1),
(10, 'Artificial Intelligence', 5, 2, 2),
(11, 'Cyber Security', 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `id` int(11) NOT NULL,
  `subjectid` int(11) NOT NULL,
  `fromtime` time NOT NULL,
  `totime` time NOT NULL,
  `day` varchar(15) NOT NULL,
  `sem` varchar(10) NOT NULL,
  `departmentid` int(50) NOT NULL,
  `facultyid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`id`, `subjectid`, `fromtime`, `totime`, `day`, `sem`, `departmentid`, `facultyid`) VALUES
(1, 2, '10:00:00', '11:00:00', 'Monday', '1', 2, 1),
(2, 3, '11:00:00', '12:00:00', 'Monday', '3', 1, 2),
(3, 4, '12:00:00', '01:00:00', 'Monday', '5', 2, 1),
(4, 5, '02:00:00', '03:00:00', 'Tuesday', '3', 1, 2),
(5, 6, '03:00:00', '04:00:00', 'Tuesday', '1', 2, 2),
(6, 7, '10:00:00', '11:00:00', 'Wednesday', '5', 1, 1),
(7, 8, '11:00:00', '12:00:00', 'Thursday', '3', 2, 2),
(8, 9, '12:00:00', '01:00:00', 'Thursday', '5', 1, 1),
(9, 10, '02:00:00', '03:00:00', 'Friday', '5', 2, 2),
(10, 11, '03:00:00', '04:00:00', 'Friday', '3', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `currentsem`
--
ALTER TABLE `currentsem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `lecturestaken`
--
ALTER TABLE `lecturestaken`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`departmentid`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `currentsem`
--
ALTER TABLE `currentsem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lecturestaken`
--
ALTER TABLE `lecturestaken`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
